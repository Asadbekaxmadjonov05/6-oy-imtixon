import Home from "./Home"
import Teacher  from "./Profile"
export {Home, Teacher}